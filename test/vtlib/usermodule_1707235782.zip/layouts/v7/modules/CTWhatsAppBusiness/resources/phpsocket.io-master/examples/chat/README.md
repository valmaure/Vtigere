# For chat demo
## start
```php start.php start``` for debug mode

```php start.php start -d``` for daemon mode

## stop
```php start.php stop```

## satus 
```php start.php status```

## restart
``` php start.php restart```

## reload
``` php start.php reload```

## connections
``` php start.php connections```
